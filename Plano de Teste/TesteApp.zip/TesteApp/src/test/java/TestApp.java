/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Marcos
 */
public class TestApp {
    TestesApp test;
    public TestApp() {
        test = new TestesApp();
    }
  /* 
   * @Test
   * public void testIgualdade_Login(){
   *     String loginInserido = "admin";
   *     String loginEsperado = "admin";
        
   *     assertEquals(loginInserido,loginEsperado);}
   */
    
    @Test
    public void testLogin(){
        //assertEquals(log.login("admin","admin"), "Login Inválido");
        assertEquals(test.login("admin","admin"), "Login Válido");
    }
    
    @Test
    public void testAvaliacao() {
        //assertEquals(test.avaliacao(3,"4"),"Ótimo");
        assertEquals(test.avaliacao(5,"5"),"Ótimo");
        //assertEquals(test.avaliacao(4,"4"),"Bom");
        //assertEquals(test.avaliacao(3,"3"),"Bom");
        //assertEquals(test.avaliacao(2,"2"),"Ruim");
        //assertEquals(test.avaliacao(1,"1"),"Ruim");
    }
    
    @Test
    public void testAvaliaComentario(){
        assertEquals(test.comment("Like"),"Você deu like no comentário");
        //assertEquals(test.comment("Dislike"),"Você deu dislike no comentário");
        //assertEquals(test.comment(""),"Comentário não avaliado");
    }
}

    


