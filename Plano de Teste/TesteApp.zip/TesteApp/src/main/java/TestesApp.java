/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marcos
 */
public class TestesApp {
    
    
    public String login = "admin";    
    public String star;
    public String like;
    public void setNumero(String star){
        this.star = star;
    }
    public String login(String login, String login_){
    
        if (login_ == login){
           return("Login Válido"); 
        }
        return("Login Inválido"); 
    }
    
 
    public String avaliacao(int nota, String star){
        if (nota == 5 && star == "5"){
            return("Ótimo");
        }else if (nota == 3 && star == "3" || nota == 4 && star == "4"){
            return("Bom");
        }else if (nota == 2 && star == "2" || nota == 2 && star == "2"){
            return("Ruim");
        }else if (nota == 1 && star == "1" || nota == 1 && star == "1"){
            return("Ruim");
        }
        return("Digite um valor válido");
    }
    public String comment(String like){
        if(like == "Like" ){
            return("Você deu like no comentário");
        }else if(like == "Dislike"){
            return("Você deu dislike no comentário");
        }
        return("Comentário não avaliado");
    }
}
